import requests
from bs4 import BeautifulSoup
from fake_useragent import UserAgent
import pandas as pd
import time

ua = UserAgent()
ua.random

headers = {"User-Agent": ua.random}

appt = {
    'title': [],
    'prix':[],
    'pieces':[],
    'nb_chambre':[],
    'surface':[],
    'etage':[],
    'ascenseur':[],
    'terrasse':[],
    'balcon':[],
    'garage':[],
    'box':[],
    'meuble':[],
    'adresse':[]
    }

for cpt in range(1,11):
    print(cpt)

    if(cpt > 1):
        url = f"https://www.seloger.com/immobilier/locations/immo-paris-75/bien-appartement/?LISTING-LISTpg={cpt}"
    else :
        url = "https://www.seloger.com/immobilier/locations/immo-paris-75/bien-appartement/"

    # url = "https://www.seloger.com/immobilier/locations/immo-paris-75/bien-appartement/"
    html = requests.get(url, headers=headers)
    if('403' in html):
        print(html)
        break
    soup = BeautifulSoup(html.content, 'html.parser')

    cards = soup.find_all('div', attrs={'data-test':'sl.card-container'})



    for info_card in cards:
        card = info_card.find('div', attrs={'data-test':'sl.detail-top'})
        title = card.find('div',attrs={'data-test':'sl.title'}).text
        prix = card.find('div',attrs={'data-test':'sl.price-label'}).text
        ul1 = card.find('ul',attrs={'data-test':'sl.tagsLine_0'}).find_all('li')

        if(info_card.find('div', attrs={'data-test':'sl.address'})):
            adresse = info_card.find('div', attrs={'data-test':'sl.address'}).text
        else:
            adresse = "Non Renseigné"    

        nb_chambre = "0"
        surface = "Non renseigné"
        pieces = "Non renseingé"
        etage = "Non renseigné"
        ascenseur = "Pas d'ascenseur"
        terrasse = "Pas de terrasse"
        balcon = "Pas de balcon"
        garage = "Pas de garage"
        box = "Pas de BOX"
        meuble = "Non meublé"

        for ul in ul1:
            if('pièces' in ul.text):
                pieces = int(ul.text.split()[0])
            
            if('chambre' in ul.text or 'ch' in ul.text):
                nb_chambre = int(ul.text.split()[0])

            if('m²' in ul.text):
                surface = ul.text

        if(card.find('ul',attrs={'data-test':'sl.tagsLine_1'})):
            ul2 = card.find('ul',attrs={'data-test':'sl.tagsLine_1'}).find_all('li')
            for ul in ul2:
                if('Ascenseur' in ul.text):
                    ascenseur = "OUI"
                if('Terrasse' in ul.text):
                    terrasse = "OUI"
                if('Balcon' in ul.text):
                    balcon = "OUI"
                if('Garage' in ul.text):
                    garage = "OUI"
                if('Box' in ul.text):
                    box = "OUI"
                if('meuble' in title):
                    meuble = "OUI"
                if('Étage' in ul.text):
                    etage = ul.text

        
            
        appt['title'].append(title)
        appt['prix'].append(prix)
        appt['pieces'].append(pieces)
        appt['nb_chambre'].append(nb_chambre)
        appt['surface'].append(surface)
        appt['etage'].append(etage)
        appt['ascenseur'].append(ascenseur)
        appt['terrasse'].append(terrasse)
        appt['balcon'].append(balcon)
        appt['garage'].append(garage)
        appt['box'].append(box)
        appt['meuble'].append(meuble)
        appt['adresse'].append(adresse)

        # time.sleep(2)



dataframe = pd.DataFrame.from_dict({
    'title': appt["title"],
    'prix':appt["prix"],
    'pieces':appt["pieces"],
    'nb_chambre':appt["nb_chambre"],
    'surface':appt["surface"],
    'etage':appt["etage"],
    'ascenseur':appt["ascenseur"],
    'terrasse':appt["terrasse"],
    'balcon':appt["balcon"],
    'garage':appt["garage"],
    'box':appt["box"],
    'meuble':appt["meuble"],
    'adresse':appt["adresse"]
})



print(dataframe)
dataframe.to_excel("Exercice4_resultat_szabo-alexandre.xlsx", index=False)



